How to load and execute .js scripts:
load("path/to/file/example.js")

You can use absolute or relative paths, depending on where your scripts are stored.